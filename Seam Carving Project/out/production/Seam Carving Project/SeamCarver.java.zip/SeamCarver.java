
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class SeamCarver {

    final int BOARDER_ENERGY = 1000;

    Picture picture;

    public SeamCarver(Picture picture)  {
        // Your code here
        this.picture = picture;
    }

    public Picture picture() {
        // Your code here
        return null;

    }

    public int width() {
        // Your code here

        return picture.width();
    }

    public int height() {
        // Your code here

        return picture.height();
    }

    public double energy(int x, int y) {
        // Your code here
        if(x < 0 || x >= width() || y < 0 || y >= height())
        {
            throw new IndexOutOfBoundsException();
        }
        if(x == 0 || x == width() - 1 || y == 0 || y == height() - 1)
        {
            return BOARDER_ENERGY;
        }

        Picture picture = new Picture("./input/3x4.png");

        int pixelEnergy1 = energyCalculation(x-1, y, x+1, y, picture);
        int pixelEnergy2 = energyCalculation(x, y-1, x, y+1, picture);
        System.out.println(Math.sqrt(pixelEnergy1 + pixelEnergy2));


        return Math.sqrt(pixelEnergy1 + pixelEnergy2);
    }

    private int energyCalculation(int x1, int y1, int x2, int y2, Picture picture)
    {
        int energy;

        Color color1 = picture.get(x1, y1);
        Color color2 = picture.get(x2, y2);

        int r1 = color1.getRed();
        int g1 = color1.getGreen();
        int b1 = color1.getBlue();
        int r2 = color2.getRed();
        int g2 = color2.getGreen();
        int b2 = color2.getBlue();

        energy = (int) Math.pow((r2 - r1), 2) + (int) Math.pow((g2 - g1), 2)
                    + (int) Math.pow((b2 - b1), 2);

        return energy;
    }

    public int[] findHorizontalSeam() {
        // Your code here

        return null;
    }

    public int[] findVerticalSeam() {
        // Your code here
        double[][] pixelsArry = new double[3][4];
        setEnergyArray(pixelsArry);

        return null;
    }

    private int findVerticalMin(int[] row)
    {
        double min;
        for(int i = 0; i < row.length; i++)
        {

        }
    }

    private void setEnergyArray(double[][] pixelsArry){

        for(int i = 0; i < pixelsArry.length; i++)
        {
            for(int j = 0; j < pixelsArry[0].length; j++)
            {
                pixelsArry[i][j] = energy(i, j);
            }
        }
    }

    public void removeHorizontalSeam(int[] seam) {
        // Your code here

    }

    public void removeVerticalSeam(int[] seam) {
        // Your code here

    }

}
