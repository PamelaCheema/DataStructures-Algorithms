public class BitTreeNode implements Comparable<Object> {
    String chr;
    int freq;
    BitTreeNode left;
    BitTreeNode right;

    public BitTreeNode(String chr, int freq) {
        this.chr = chr;
        this.freq = freq;
        right = null;
        left = null;
    }

    public BitTreeNode(BitTreeNode left, BitTreeNode right) {
     this.left = left;
     this.right = right;
    }

    public String getChr() {
         return chr;
    }

    public int getFreq()
    {
        return freq;
    }


    public String toString()
    {
        return "Character: " + chr + "      " + "Frequency: " + freq +  "      ";
    }

    @Override
    public int compareTo(Object o) {
        return 0;
    }


    public int compareTo(BitTreeNode o) {
        return this.freq - o.freq;
    }
 }
