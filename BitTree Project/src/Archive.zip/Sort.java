public class Sort {

    public Sort(BitTreeNode[] btn)
    {
        int[] frequencies = new int[btn.length];
        for()
    }
    public static void bubble(int[] data)
    {
        int temp = 0;

        boolean switched = true;

        int numSwitched = 0;

        while(switched)
        {
            for(int i = 0; i < data.length - 1; i++)
            {
                if(data[i + 1] < data[i])
                {
                    temp = data[i + 1];
                    data[i + 1] = data[i];
                    data[i] = temp;
                    numSwitched++;
                }
            }

            if(numSwitched > 0)
            {
                switched = true;
            }else{
                switched = false;
            }
            numSwitched = 0;
        }

        for(int i = 0; i < data.length; i++)
        {
            System.out.println(data[i]);
        }
    }
}
