import jdk.nashorn.api.tree.BinaryTree;

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class BitTree {


    private Map<String, Integer> characters = new TreeMap<String, Integer>();

    private PriorityQueue<BitTreeNode> charQueue = new PriorityQueue<BitTreeNode>();

    private BitTreeNode[] charArray;



    String fileName;
    String fExt;
    File f;
    FileReader fr;
    BufferedReader br;

    public BitTree(String fileName, String fExt)
    {
        this.fileName = fileName;
        this.fExt = fExt;

        encode(fileName, fExt);

    }

    public void encode(String fileName, String fExt)
    {
        addCharacters(fileName, fExt);

        System.out.println(toString());

        priorityChars();

        System.out.println("Priority Queue: " + printQueue());

        setCharArray();

        Heapsort.sort(charArray);

    }

    /**
     * adds all the characters from the text file into a Tree Map
     * @param fileName
     * @param fExt
     */
    private void addCharacters(String fileName, String fExt)
    {
        try{
            fileName = "./input/" + fileName + fExt;

            f = new File(fileName);

            fr = new FileReader(f);

            br = new BufferedReader(fr);

            String current;

            String[] temp;

            //Parses through file and adds characters to tree map
            while(br.ready())
            {
                current = br.readLine();

                temp = current.split("");

                for(int i = 0; i < temp.length; i++)
                {

                    if(checkSpecialChar(temp[i]) != null)
                    {

                        temp[i] = checkSpecialChar(temp[i]);

                    }
                    if(characters.containsKey(temp[i]))
                    {

                        characters.replace(temp[i], characters.get(temp[i]) + 1);

                    }else {

                        characters.put(temp[i], 1);

                    }
                }
                characters.put("EOF", 1);
            }

        }catch(Exception e){

            e.printStackTrace();

        }
    }

    /**
     * puts all the elements from the character map into an array of BitTreeNodes
     */
    private void setCharArray()
    {
        int index = 0;
        Iterator<String> list = characters.keySet().iterator();
        String currentKey;

        while(list.hasNext())
        {
            currentKey = list.next();
            //int ascii = (int)
            BitTreeNode temp = new BitTreeNode(currentKey, characters.get(currentKey));
            charQueue.add(temp);
            charArray = new BitTreeNode[characters.size()];
            index++;
        }
    }

    /**
     * puts all the elements from the map into a priority queue
     */
    private void priorityChars()
    {
        Iterator<String> list = characters.keySet().iterator();
        String currentKey;

        while(list.hasNext())
        {

            currentKey = list.next();
            //int ascii = (int)
            BitTreeNode temp = new BitTreeNode(currentKey, characters.get(currentKey));
            charQueue.add(temp);
            //charArray = new BitTreeNode[characters.size()];

        }
    }

    /**
     * Checks for space and new line special characters
     * @param key
     * @return key type
     */
    private String checkSpecialChar(String key)
    {
       if(key.equals(" "))
       {
           return "sp.";
       }else if(key.equals(""))
       {
           return "nl";
       }

       return null;
    }


    /**
     * prints the queue of BitTreeNodes
     * @return
     */
    private String printQueue()
    {
        return "" + charQueue;
    }

    /**
     *
     * @return elements in characters map
     */
    public String toString()
    {
        String allCharacters = "";

        Iterator<String> list = characters.keySet().iterator();

        String currentKey;

        while(list.hasNext())
        {

            currentKey = list.next();

            allCharacters += currentKey + " " + characters.get(currentKey) + "\n";

        }

        return allCharacters;
    }

    public void decode()
    {

    }
}
