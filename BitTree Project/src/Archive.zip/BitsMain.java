
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class BitsMain {

    public static void main(String[] args)
    {
        BitTree bt = new BitTree("jumpingfrog", ".txt");
        //System.out.println(bt.toString());
    }

}
