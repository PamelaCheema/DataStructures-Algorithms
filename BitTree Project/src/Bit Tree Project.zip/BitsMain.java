
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;

public class BitsMain {

    public static void main(String[] args)
    {
        //BitTree bt = new BitTree("example2", ".txt");
        BT bt = new BT("example2", ".txt");
        //bt.encode();
        //bt.compress();
        //bt.decompress();
       // bt.print();
    }

}
